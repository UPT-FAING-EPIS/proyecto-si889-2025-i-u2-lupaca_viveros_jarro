<?php
namespace Utils;

class Helper {
    public static function log(string $msg) {
        echo "[LOG]: " . $msg;
    }
}
