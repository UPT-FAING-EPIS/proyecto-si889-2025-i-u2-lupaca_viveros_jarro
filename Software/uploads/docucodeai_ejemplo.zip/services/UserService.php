<?php
require_once '../utils/Logger.php';

class UserService {
    public function authenticate($user, $pass) {
        $logger = new Logger();
        $logger->info("Autenticando $user");
        return true;
    }

    public function createUser($user, $pass) {
        $logger = new Logger();
        $logger->info("Creando usuario $user");
        return true;
    }
}