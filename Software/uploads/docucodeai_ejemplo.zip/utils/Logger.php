<?php
class Logger {
    public function info($msg) {
        echo "[INFO] " . $msg;
    }

    public function error($msg) {
        echo "[ERROR] " . $msg;
    }
}