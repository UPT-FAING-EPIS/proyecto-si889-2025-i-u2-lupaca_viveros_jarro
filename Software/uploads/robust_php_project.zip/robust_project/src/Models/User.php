<?php
namespace Models;

class User {
    private $username;
    private $password;
    private $authenticated = false;

    public function __construct($username, $password) {
        $this->username = $username;
        $this->password = $password;
    }

    public function authenticate() {
        if ($this->username === 'admin' && $this->password === '1234') {
            $this->authenticated = true;
        }
        return $this->authenticated;
    }

    public function getUsername() {
        return $this->username;
    }
}
