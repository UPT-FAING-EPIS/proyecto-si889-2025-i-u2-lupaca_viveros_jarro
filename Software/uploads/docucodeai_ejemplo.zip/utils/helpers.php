<?php
function sanitizeInput($input) {
    return trim(htmlspecialchars($input));
}

function sanitizeInput($input) {
    return trim(htmlspecialchars($input));
}