<?php
namespace Controllers;

use Models\User;
use Services\Logger;
use Services\NotificationService;

class AuthController {
    public function login($username, $password) {
        $user = new User($username, $password);
        if ($user->authenticate()) {
            Logger::info("Usuario autenticado: " . $user->getUsername());
            NotificationService::notify($user->getUsername(), "Bienvenido al sistema");
        }
    }
}
