<?php
namespace Services;

class NotificationService {
    public static function notify($to, $msg) {
        echo "Notification sent to $to: $msg";
    }
}
