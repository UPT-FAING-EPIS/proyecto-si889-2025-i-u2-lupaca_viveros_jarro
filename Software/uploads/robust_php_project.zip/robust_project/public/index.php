<?php
require_once '../src/Controllers/AuthController.php';
require_once '../src/Controllers/ProductController.php';

use Controllers\AuthController;
use Controllers\ProductController;

$auth = new AuthController();
$auth->login('admin', '1234');

$products = new ProductController();
$products->listAll();
