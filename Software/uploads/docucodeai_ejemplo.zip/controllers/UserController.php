<?php
require_once '../services/UserService.php';

class UserController {
    public function login() {
        $service = new UserService();
        $service->authenticate("admin", "1234");
    }

    public function register() {
        $service = new UserService();
        $service->createUser("newuser", "pass");
    }
}