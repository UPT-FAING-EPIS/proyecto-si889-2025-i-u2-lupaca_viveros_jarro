<?php
namespace Services;

class Logger {
    public static function info($message) {
        echo "[INFO] " . $message . "\n";
    }
}
