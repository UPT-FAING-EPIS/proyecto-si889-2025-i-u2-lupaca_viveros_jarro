<?php
namespace Repositories;

use Models\Product;

class ProductRepository {
    public function fetchAll() {
        return [
            new Product("Laptop Pro", 1899.99),
            new Product("Tablet X", 599.99),
            new Product("Smartphone X", 999.99),
        ];
    }
}
