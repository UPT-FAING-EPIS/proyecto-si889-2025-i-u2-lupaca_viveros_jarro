<?php
namespace Controllers;

use Repositories\ProductRepository;

class ProductController {
    public function listAll() {
        $repo = new ProductRepository();
        $allProducts = $repo->fetchAll();

        foreach ($allProducts as $product) {
            echo $product->getName() . " - " . $product->getPriceFormatted();
        }
    }
}
